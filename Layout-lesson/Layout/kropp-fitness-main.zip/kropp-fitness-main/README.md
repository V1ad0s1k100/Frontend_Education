# kropp-fitness
Адаптивная верстка сайта по макету Александра Ламкова
[Плейлист](https://youtube.com/playlist?list=PL0MUAHwery4rqkzKF1mDBCIH_eZgjY6uN&si=3Uqb7trqQUIL25LB)
